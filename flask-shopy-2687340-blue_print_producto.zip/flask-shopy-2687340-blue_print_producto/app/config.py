class Config:
    #definir la "cadena de conexion" (connection )
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:@localhost:3306/Flask-shopy-2687340'
    SQLALCHEMY_TRACK_NOTIFICATIONS = False
    SECRET_KEY = '2687340'